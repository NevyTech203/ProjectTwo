#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 27 15:55:26 2024

@author: nevenayoung_snhu
"""


from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    
    def __init__(self, username, password, grazioso_image):
        
        USER = 'aacuser'
        PASS = 'SNHU3214'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30680
        DB = 'AAC'
        COL = 'animals'
        USERNAME = USER
        PASSWORD = PASS
        grazioso_image = 'Grazioso Salvare Logo.png'
        
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        print("Connected succesfully to MongoDB")
        
        
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)
            return True
           
        else:
            raise Exception("Nothing to save, because data parameter is empty")
        
    
    def read(self, query):
        if query is not None:
            cursor = self.database.animals.find(query)
            return cursor
        else:
            raise Exception("Nothing to read, query parameter is empty")
            return False
        
    def update(self, query, new_data):
        if query is not None:
            result = self.database.animals.update_one(query, {"$set":new_data})
            if result.modified_count > 0:
                return result.raw_result
            else:
                raise Exception("No query provided for update")
                return False

    def delete(self, query):
        if query is not None:
            result = self.database.animals.delete_one(query)
            if result.deleted_count > 0:
                return result.raw_result
            else:
                raise Exception("No data provided for delete")
                return False
        
                
        